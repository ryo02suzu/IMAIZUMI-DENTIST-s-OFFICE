"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Phone } from "lucide-react"

const navItems = [
  { label: "はじめての方へ", href: "#about" },
  { label: "診療内容", href: "#treatment" },
  { label: "医師紹介", href: "#doctor" },
  { label: "院内のご紹介", href: "#facility" },
  { label: "アクセス", href: "#access" },
  { label: "お問い合わせ", href: "#contact" },
]

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="bg-card sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="#" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#7eb4d2] flex items-center justify-center">
              <span className="text-white text-[8px] font-bold leading-tight text-center">
                今泉<br/>歯科
              </span>
            </div>
            <div>
              <p className="text-[#7eb4d2] font-bold text-lg tracking-wide">今泉歯科医院</p>
              <p className="text-[#7eb4d2] text-[10px] tracking-widest">IMAIZUMI DENTAL CLINIC</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="text-[#4a4a4a] text-sm hover:text-[#7eb4d2] transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* CTA and Phone */}
          <div className="hidden md:flex items-center gap-4">
            <Link
              href="https://functional-prototype.replit.app/book/imaizumi-dental"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#f5a623] text-white text-xs px-4 py-2 rounded-full hover:bg-[#e09520] transition-colors"
            >
              ご予約・お問い合わせ
            </Link>
            <div className="text-right">
              <p className="text-[#7eb4d2] text-xs">TEL</p>
              <p className="text-[#7eb4d2] text-xl font-bold tracking-wider">近日公開</p>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-[#4a4a4a]"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="メニュー"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="lg:hidden py-4 border-t border-border">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="block py-3 text-[#4a4a4a] hover:text-[#7eb4d2] border-b border-border/50"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-4 space-y-3">
              <Link
                href="https://functional-prototype.replit.app/book/imaizumi-dental"
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-[#f5a623] text-white text-center py-3 rounded-full"
              >
                ご予約・お問い合わせ
              </Link>
              <div className="flex items-center justify-center gap-2 text-[#7eb4d2]">
                <Phone className="h-4 w-4" />
                <span className="text-lg font-bold">近日公開</span>
              </div>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
