"use client"

import { Navigation } from "@/components/dental/navigation"
import { Hero } from "@/components/dental/hero"
import { Treatment } from "@/components/dental/treatment"
import { About } from "@/components/dental/about"
import { Features } from "@/components/dental/features"
import { Checkup } from "@/components/dental/checkup"
import { Gallery } from "@/components/dental/gallery"
import { News } from "@/components/dental/news"
import { Contact } from "@/components/dental/contact"
import { MapSection } from "@/components/dental/map"
import { Footer } from "@/components/dental/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <Hero />
      <Treatment />
      <About />
      <Features />
      <Checkup />
      <Gallery />
      <News />
      <Contact />
      <MapSection />
      <Footer />
    </main>
  )
}
